import React from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface ProjectCardProps {
  title: string;
  description: string;
  skills: string[];
}

const ProjectCard = ({
  title = "Project Title",
  description = "A brief description of the project and its impact.",
  skills = ["Skill 1", "Skill 2", "Skill 3"],
}: ProjectCardProps) => {
  return (
    <Card className="h-full overflow-hidden transition-all hover:shadow-md bg-white">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-semibold text-sky-700">
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <CardDescription className="text-sm text-gray-600 mb-4">
          {description}
        </CardDescription>
        <div className="flex flex-wrap gap-2">
          {skills.map((skill, index) => (
            <Badge
              key={index}
              variant="outline"
              className="bg-sky-50 text-sky-700 hover:bg-sky-100 border-sky-200"
            >
              {skill}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default ProjectCard;
