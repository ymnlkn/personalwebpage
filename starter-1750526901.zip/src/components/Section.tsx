import React, { ReactNode } from "react";

interface SectionProps {
  id: string;
  title: string;
  children: ReactNode;
  className?: string;
}

const Section = ({ id, title, children, className = "" }: SectionProps) => {
  return (
    <section
      id={id}
      className={`min-h-[600px] w-full py-16 px-4 md:px-8 lg:px-16 bg-white ${className}`}
    >
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold mb-8 text-sky-600">
          {title}
        </h2>
        <div className="section-content">{children}</div>
      </div>
    </section>
  );
};

export default Section;
