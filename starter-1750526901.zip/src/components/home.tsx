import { motion, useScroll, useTransform, useInView } from "framer-motion";
import { useRef, useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  Mail,
  Phone,
  Linkedin,
  Github,
  MapPin,
  Calendar,
  Code,
  Database,
  BarChart3,
  Globe,
  Briefcase,
  GraduationCap,
  Moon,
  Sun,
  Download,
} from "lucide-react";

const AnimatedSection = ({
  children,
  className = "",
  delay = 0,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
      transition={{ duration: 0.8, delay, ease: "easeOut" }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

const Card3D = ({
  children,
  className = "",
  hoverScale = true,
}: {
  children: React.ReactNode;
  className?: string;
  hoverScale?: boolean;
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, rotateX: 15, y: 50 }}
      whileInView={{ opacity: 1, rotateX: 0, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      whileHover={
        hoverScale
          ? {
              scale: 1.02,
              rotateX: -2,
              rotateY: 2,
              boxShadow: "0 25px 50px -12px rgba(59, 130, 246, 0.25)",
            }
          : {}
      }
      transition={{ duration: 0.6, ease: "easeOut" }}
      className={cn("transform-gpu perspective-1000", className)}
      style={{ transformStyle: "preserve-3d" }}
    >
      {children}
    </motion.div>
  );
};

const HoverCard = ({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) => {
  return (
    <motion.div
      whileHover={{
        scale: 1.05,
        y: -5,
        boxShadow: "0 20px 40px -12px rgba(59, 130, 246, 0.3)",
      }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className={cn("cursor-pointer", className)}
    >
      {children}
    </motion.div>
  );
};

function Home() {
  const { scrollYProgress } = useScroll();
  const parallaxY = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);
  const [activeSection, setActiveSection] = useState("home");
  const [darkMode, setDarkMode] = useState(false);
  const [navVisible, setNavVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [typingText, setTypingText] = useState("");
  const [typingIndex, setTypingIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  const typingTexts = [
    "AI Explorer",
    "Data Enthusiast",
    "Business & Economics Student",
    "Insight-Driven Thinker",
    "Lifelong Learner",
  ];

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;

      // Handle nav visibility
      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setNavVisible(false);
      } else {
        setNavVisible(true);
      }
      setLastScrollY(currentScrollY);

      // Handle active section
      const sections = ["home", "experience", "skills", "projects", "contact"];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (
            scrollPosition >= offsetTop &&
            scrollPosition < offsetTop + offsetHeight
          ) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [lastScrollY]);

  // Typing animation effect
  useEffect(() => {
    const timeout = setTimeout(
      () => {
        const currentText = typingTexts[typingIndex];

        if (!isDeleting) {
          if (charIndex < currentText.length) {
            setTypingText(currentText.substring(0, charIndex + 1));
            setCharIndex(charIndex + 1);
          } else {
            setTimeout(() => setIsDeleting(true), 2000);
          }
        } else {
          if (charIndex > 0) {
            setTypingText(currentText.substring(0, charIndex - 1));
            setCharIndex(charIndex - 1);
          } else {
            setIsDeleting(false);
            setTypingIndex((typingIndex + 1) % typingTexts.length);
          }
        }
      },
      isDeleting ? 50 : 100,
    );

    return () => clearTimeout(timeout);
  }, [charIndex, isDeleting, typingIndex, typingTexts]);

  // Dark mode effect
  useEffect(() => {
    const savedMode = localStorage.getItem("darkMode");
    if (savedMode) {
      setDarkMode(JSON.parse(savedMode));
    } else {
      // Default to dark mode if no preference is saved
      setDarkMode(true);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("darkMode", JSON.stringify(darkMode));
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);

  return (
    <div
      className={`min-h-screen relative overflow-x-hidden font-['Inter',_'Poppins',_sans-serif] ${darkMode ? "dark bg-gradient-to-br from-gray-900 via-gray-800 to-blue-900" : "bg-gradient-to-br from-blue-50 via-white to-blue-100"}`}
    >
      {/* Parallax Background */}
      <motion.div
        className="fixed inset-0 z-0 opacity-30"
        style={{ y: parallaxY }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-blue-200/20 via-transparent to-blue-300/20" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-200/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-blue-300/10 rounded-full blur-3xl" />
      </motion.div>

      {/* Floating Navigation Buttons */}
      <motion.div
        initial={{ x: -100, opacity: 0 }}
        animate={{ x: navVisible ? 0 : -100, opacity: navVisible ? 1 : 0 }}
        transition={{ duration: 0.3, ease: "easeOut" }}
        className="fixed top-6 left-6 z-50 flex flex-col space-y-3"
      >
        {[
          { id: "home", label: "Home" },
          { id: "experience", label: "Experience" },
          { id: "skills", label: "Skills" },
          { id: "projects", label: "Projects" },
          { id: "contact", label: "Contact" },
        ].map((item) => (
          <motion.button
            key={item.id}
            whileHover={{ scale: 1.1, x: 5 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => scrollToSection(item.id)}
            className={cn(
              "px-3 py-2 text-sm font-medium transition-all duration-200 rounded-lg backdrop-blur-sm",
              darkMode
                ? "text-gray-300 hover:text-blue-300 hover:bg-gray-800/50"
                : "text-gray-700 hover:text-blue-900 hover:bg-white/50",
              activeSection === item.id &&
                (darkMode
                  ? "text-blue-300 bg-gray-800/70 font-semibold"
                  : "text-blue-900 bg-white/70 font-semibold"),
            )}
          >
            {item.label}
          </motion.button>
        ))}

        {/* Dark Mode Toggle */}
        <motion.button
          whileHover={{ scale: 1.1, x: 5 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setDarkMode(!darkMode)}
          className={`p-2 rounded-lg backdrop-blur-sm transition-all duration-200 ${
            darkMode
              ? "text-yellow-400 hover:bg-gray-800/50"
              : "text-blue-900 hover:bg-white/50"
          }`}
        >
          {darkMode ? <Sun size={18} /> : <Moon size={18} />}
        </motion.button>
      </motion.div>

      {/* Hero Section */}
      <section
        id="home"
        className={`min-h-screen flex items-center justify-center relative z-10 ${
          darkMode
            ? "bg-gradient-to-br from-gray-900 to-blue-900"
            : "bg-gradient-to-br from-blue-50 to-blue-100"
        }`}
      >
        <div className="max-w-4xl mx-auto px-6">
          <div className="flex flex-col items-center text-center space-y-8">
            {/* Name */}
            <motion.h1
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className={`text-5xl lg:text-6xl font-bold ${
                darkMode ? "text-blue-300" : "text-blue-900"
              }`}
            >
              Hi, I'm Yaman Alkın.
            </motion.h1>

            <motion.div
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className={`text-xl font-semibold h-8 ${
                darkMode ? "text-blue-400" : "text-blue-700"
              }`}
            >
              {typingText}
              <span className="animate-pulse">|</span>
            </motion.div>

            <motion.p
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className={`text-lg ${
                darkMode ? "text-gray-300" : "text-blue-700"
              }`}
            >
              Data-driven thinker passionate about using numbers to understand,
              explain, and improve the world.
            </motion.p>

            {/* Profile Image */}
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="flex justify-center"
            >
              <motion.img
                whileHover={{ scale: 1.05, rotateY: 5 }}
                transition={{ duration: 0.3 }}
                src="/yaman.jpg"
                alt="Yaman Alkın"
                className="w-32 h-32 sm:w-36 sm:h-36 md:w-40 md:h-40 lg:w-44 lg:h-44 rounded-full object-cover"
              />
            </motion.div>

            {/* Summary Text */}
            <motion.div
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className={`space-y-4 leading-relaxed text-justify max-w-4xl ${
                darkMode ? "text-gray-300" : "text-gray-700"
              }`}
            >
              <p>
                I'm currently studying Business and Economics at the University
                of Bologna, where I combine my interests in business, data, and
                human behavior to explore how data can drive better decisions.
                I'm especially drawn to the intersection of artificial
                intelligence and analytics where raw information is transformed
                into intelligent insights.
              </p>

              <p>
                Over the years, I've become deeply curious about how machines
                learn, how systems evolve, and how people interact with both.
                From experimenting with machine learning tools to following the
                latest AI research, I'm constantly pushing myself to understand
                what's next and how I can contribute to it.
              </p>

              <p>
                Outside of tech and business, I'm equally fascinated by
                psychology, philosophy, and history fields that shape the way I
                think, communicate, and grow. I believe that blending technical
                skill with human insight is what leads to the most impactful
                solutions.
              </p>

              <p>
                At my core, I'm someone who asks: &quot;Can I make this
                better?&quot; That mindset has guided my personal development,
                academic journey, and creative problem-solving. I believe in
                lifelong learning, thoughtful execution, and building meaningful
                things that last.
              </p>

              <p
                className={`font-medium ${
                  darkMode ? "text-blue-400" : "text-blue-800"
                }`}
              >
                Thanks for stopping by I'm just getting started, and there's so
                much more I'm excited to explore.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <Card3D>
        <section
          id="experience"
          className={`py-20 relative z-10 ${
            darkMode ? "bg-gray-900/50" : "bg-blue-50/50"
          }`}
        >
          <div className="max-w-6xl mx-auto px-6">
            <AnimatedSection>
              <h2
                className={`text-4xl font-bold text-center mb-16 ${
                  darkMode ? "text-blue-300" : "text-blue-900"
                }`}
              >
                Experience
              </h2>
            </AnimatedSection>

            <div className="space-y-8">
              {[
                {
                  title: "Project Management Intern",
                  company: "Alhatoglu Olive Oil Co.",
                  period: "July 2024 – August 2024",
                  description:
                    "Collaborated with the international sales team for Walmart, preparing reports and communicating with executives to enhance operations. Developed a payment plan and managed on-call duties, ensuring accurate financial records and proofreading customer communications.",
                },
                {
                  title: "Research Assistant Intern",
                  company: "Topkapı University – Department of Economics",
                  period: "July 2023 – August 2023",
                  description:
                    "Developed critical thinking skills by interpreting complex economic data under the mentorship of Prof. Dr. Emre Alkin. Contributed to the preparation of economic discussions, showcasing ability to engage with critical financial concepts and current economic issues.",
                },
              ].map((experience, index) => (
                <AnimatedSection key={index} delay={index * 0.2}>
                  <motion.div
                    whileHover={{ y: -5, scale: 1.02, rotateX: 2, rotateY: -2 }}
                    transition={{ duration: 0.3, ease: "easeOut" }}
                    className="transform-gpu"
                    style={{ transformStyle: "preserve-3d" }}
                  >
                    <Card
                      className={`backdrop-blur-sm shadow-lg ${
                        darkMode
                          ? "bg-gray-800/90 border-gray-700"
                          : "bg-white/90 border-blue-200"
                      }`}
                    >
                      <CardContent className="p-6">
                        <h3
                          className={`text-xl font-semibold mb-2 ${
                            darkMode ? "text-blue-300" : "text-blue-900"
                          }`}
                        >
                          {experience.title}
                        </h3>
                        <h4
                          className={`text-lg font-medium mb-2 ${
                            darkMode ? "text-blue-400" : "text-blue-700"
                          }`}
                        >
                          {experience.company}
                        </h4>
                        <p
                          className={`text-sm font-medium mb-4 ${
                            darkMode ? "text-gray-400" : "text-gray-600"
                          }`}
                        >
                          {experience.period}
                        </p>
                        <p
                          className={`leading-relaxed text-justify ${
                            darkMode ? "text-gray-300" : "text-gray-700"
                          }`}
                        >
                          {experience.description}
                        </p>
                      </CardContent>
                    </Card>
                  </motion.div>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </section>
      </Card3D>

      {/* Skills Section */}
      <Card3D>
        <section
          id="skills"
          className={`py-20 relative z-10 ${
            darkMode ? "bg-gray-800/50" : "bg-white/50"
          }`}
        >
          <div className="max-w-6xl mx-auto px-6">
            <AnimatedSection>
              <h2
                className={`text-4xl font-bold text-center mb-16 ${
                  darkMode ? "text-blue-300" : "text-blue-900"
                }`}
              >
                Skills & Expertise
              </h2>
            </AnimatedSection>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  icon: "🧮",
                  title: "Financial Analysis",
                  description:
                    "DCF modeling, forecasting, financial ratios, NPV/IRR, break-even and variance analysis.",
                },
                {
                  icon: "📊",
                  title: "Microsoft Excel",
                  description:
                    "Power Query, pivot tables, valuation models, dashboards, advanced formulas.",
                },
                {
                  icon: "🧠",
                  title: "Artificial Intelligence",
                  description:
                    "Prompt engineering, AI experimentation with ChatGPT, Gemini, and Copilot.",
                },
                {
                  icon: "🐍",
                  title: "Python",
                  description:
                    "Pandas, Matplotlib, Seaborn, NumPy, Scikit-learn, EDA, and feature engineering.",
                },
                {
                  icon: "🗃️",
                  title: "SQL",
                  description:
                    "JOINs, nested subqueries, CASE WHEN logic, and real-time data filtering.",
                },
                {
                  icon: "🧷",
                  title: "Microsoft Office",
                  description:
                    "Word, PowerPoint, Outlook, and Teams — polished business documentation.",
                },
              ].map((skill, index) => (
                <AnimatedSection key={index} delay={index * 0.1}>
                  <motion.div
                    whileHover={{ y: -5, scale: 1.05 }}
                    transition={{ duration: 0.3, ease: "easeOut" }}
                    className="h-full"
                  >
                    <Card
                      className={`h-full backdrop-blur-sm shadow-lg transition-all duration-300 ${
                        darkMode
                          ? "bg-gray-800/90 border-gray-700 hover:shadow-xl"
                          : "bg-blue-50/90 border-blue-200 hover:shadow-xl hover:bg-blue-100/90"
                      }`}
                    >
                      <CardContent className="p-6 flex flex-col h-full">
                        <div className="text-3xl mb-3 text-center">
                          {skill.icon}
                        </div>
                        <h3
                          className={`text-lg font-bold mb-3 text-center ${
                            darkMode ? "text-blue-300" : "text-blue-900"
                          }`}
                        >
                          {skill.title}
                        </h3>
                        <p
                          className={`text-sm leading-relaxed text-justify flex-grow ${
                            darkMode ? "text-gray-300" : "text-gray-700"
                          }`}
                        >
                          {skill.description}
                        </p>
                      </CardContent>
                    </Card>
                  </motion.div>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </section>
      </Card3D>

      {/* Projects Section */}
      <Card3D>
        <section
          id="projects"
          className={`py-20 relative z-10 ${
            darkMode ? "bg-gray-900/50" : "bg-blue-50/50"
          }`}
        >
          <div className="max-w-6xl mx-auto px-6">
            <AnimatedSection>
              <h2
                className={`text-4xl font-bold text-center mb-16 ${
                  darkMode ? "text-blue-300" : "text-blue-900"
                }`}
              >
                Featured Projects
              </h2>
            </AnimatedSection>

            <div className="space-y-8">
              {[
                {
                  title: "Sales Uplift Analysis – Online Retail Store",
                  subtitle: "Available on GitHub",
                  description:
                    "Applied time series forecasting (Facebook Prophet) to estimate counterfactual sales and quantify marketing ROI. Conducted full-cycle data analysis: cleaning, exploratory analysis, statistical modeling, and visualization.",
                  skills:
                    "Python (Pandas, Matplotlib), causal inference, uplift modeling, time series analysis, KPI reporting, business impact evaluation",
                  link: "https://github.com/ymnlkn/Sales-Uplifting",
                  linkLabel: "📎 Open GitHub Repo",
                },
                {
                  title:
                    "FGS Business Game Challenge – Casa Luna Luxury Market Entry Strategy",
                  description:
                    "Proposed Casa Luna's entry into Turkey via pop-up stores and experiential retail. Developed brand positioning using SWOT, STP, and market research. Finalist among 60+ teams in Europe-wide strategy competition.",
                  download: "/Casa_Luna.pdf",
                  downloadLabel: "📎 Download Presentation PDF",
                },
                {
                  title:
                    "BMW vs. Mercedes-Benz Financial Analysis – University of Bologna Group Project",
                  description:
                    "Led BMW's DCF valuation and financial modeling. Analyzed profitability, solvency, and ROE vs. Mercedes-Benz. Applied PESTEL and Porter's Five Forces for strategic insights.",
                  downloads: [
                    {
                      label: "📎 Download Excel Model",
                      file: "/bmw_excel.xlsx",
                    },
                    {
                      label: "📎 Download Summary PDF",
                      file: "/fa_summary.pdf",
                    },
                  ],
                },
              ].map((project, index) => (
                <AnimatedSection key={index} delay={index * 0.2}>
                  <motion.div
                    whileHover={{ y: -5, scale: 1.02, rotateX: 2, rotateY: -2 }}
                    transition={{ duration: 0.3, ease: "easeOut" }}
                    className="transform-gpu"
                    style={{ transformStyle: "preserve-3d" }}
                  >
                    <Card
                      className={`backdrop-blur-sm shadow-lg ${
                        darkMode
                          ? "bg-gray-800/90 border-gray-700"
                          : "bg-white/90 border-blue-200"
                      }`}
                    >
                      <CardContent className="p-6">
                        <h3
                          className={`text-xl font-semibold mb-2 ${
                            darkMode ? "text-blue-300" : "text-blue-900"
                          }`}
                        >
                          {project.title}
                        </h3>
                        {project.subtitle && (
                          <p
                            className={`text-sm font-medium mb-4 ${
                              darkMode ? "text-blue-400" : "text-blue-700"
                            }`}
                          >
                            {project.subtitle}
                          </p>
                        )}
                        <p
                          className={`leading-relaxed text-justify mb-4 ${
                            darkMode ? "text-gray-300" : "text-gray-700"
                          }`}
                        >
                          {project.description}
                        </p>
                        {project.skills && (
                          <p
                            className={`text-sm leading-relaxed text-justify mb-6 ${
                              darkMode ? "text-gray-400" : "text-gray-600"
                            }`}
                          >
                            <span className="font-medium">Skills:</span>{" "}
                            {project.skills}
                          </p>
                        )}
                        <div className="flex flex-wrap gap-3">
                          {project.link && (
                            <motion.a
                              href={project.link}
                              target="_blank"
                              rel="noopener noreferrer"
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                                darkMode
                                  ? "bg-blue-800 text-blue-200 hover:bg-blue-700"
                                  : "bg-blue-600 text-white hover:bg-blue-700"
                              }`}
                            >
                              {project.linkLabel}
                            </motion.a>
                          )}
                          {project.download && (
                            <motion.a
                              href={project.download}
                              download
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                                darkMode
                                  ? "bg-blue-800 text-blue-200 hover:bg-blue-700"
                                  : "bg-blue-600 text-white hover:bg-blue-700"
                              }`}
                            >
                              {project.downloadLabel}
                            </motion.a>
                          )}
                          {project.downloads &&
                            project.downloads.map((download, downloadIndex) => (
                              <motion.a
                                key={downloadIndex}
                                href={download.file}
                                download
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                                className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                                  darkMode
                                    ? "bg-blue-800 text-blue-200 hover:bg-blue-700"
                                    : "bg-blue-600 text-white hover:bg-blue-700"
                                }`}
                              >
                                {download.label}
                              </motion.a>
                            ))}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </section>
      </Card3D>

      {/* Contact Section */}
      <Card3D>
        <section
          id="contact"
          className={`py-20 relative z-10 ${
            darkMode ? "bg-gray-800/50" : "bg-white/50"
          }`}
        >
          <div className="max-w-4xl mx-auto px-6">
            <AnimatedSection>
              <h2
                className={`text-4xl font-bold text-center mb-16 ${
                  darkMode ? "text-blue-300" : "text-blue-900"
                }`}
              >
                Get In Touch
              </h2>
            </AnimatedSection>

            <motion.div
              whileHover={{ rotateX: 2, rotateY: -2 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="transform-gpu"
              style={{ transformStyle: "preserve-3d" }}
            >
              <Card
                className={`backdrop-blur-sm shadow-xl ${
                  darkMode
                    ? "bg-gray-800/90 border-gray-700"
                    : "bg-white/90 border-blue-200"
                }`}
              >
                <CardContent className="p-8">
                  <AnimatedSection delay={0.2}>
                    <p
                      className={`text-center text-lg mb-8 leading-relaxed ${
                        darkMode ? "text-gray-300" : "text-gray-700"
                      }`}
                    >
                      I'm always interested in discussing new opportunities,
                      collaborations, or simply connecting with fellow data
                      enthusiasts and business professionals. Feel free to reach
                      out!
                    </p>
                  </AnimatedSection>

                  <div className="grid md:grid-cols-2 gap-6">
                    {[
                      {
                        icon: <Mail className="w-6 h-6" />,
                        label: "Email",
                        value: "yamanalkin9@gmail.com",
                        href: "mailto:yamanalkin9@gmail.com",
                      },
                      {
                        icon: <Phone className="w-6 h-6" />,
                        label: "Phone",
                        value: "+39 344 471 9908",
                        href: "tel:+393444719908",
                      },
                      {
                        icon: <Linkedin className="w-6 h-6" />,
                        label: "LinkedIn",
                        value: "linkedin.com/in/yaman-alkin",
                        href: "https://www.linkedin.com/in/yaman-alkin/",
                      },
                      {
                        icon: <Github className="w-6 h-6" />,
                        label: "GitHub",
                        value: "github.com/ymnlkn",
                        href: "https://github.com/ymnlkn",
                      },
                    ].map((contact, index) => (
                      <AnimatedSection key={index} delay={0.3 + index * 0.1}>
                        <motion.div
                          whileHover={{ y: -3, scale: 1.02 }}
                          transition={{ duration: 0.3, ease: "easeOut" }}
                        >
                          <a
                            href={contact.href}
                            target="_blank"
                            rel="noopener noreferrer"
                            className={`block p-4 rounded-lg border transition-colors ${
                              darkMode
                                ? "bg-blue-900/30 border-blue-700 hover:bg-blue-800/40"
                                : "bg-blue-50 border-blue-200 hover:bg-blue-100"
                            }`}
                          >
                            <div className="flex items-center space-x-4">
                              <motion.div
                                whileHover={{ rotate: 360 }}
                                transition={{ duration: 0.5 }}
                                className={
                                  darkMode ? "text-blue-400" : "text-blue-700"
                                }
                              >
                                {contact.icon}
                              </motion.div>
                              <div>
                                <p
                                  className={`font-semibold ${
                                    darkMode ? "text-blue-300" : "text-blue-900"
                                  }`}
                                >
                                  {contact.label}
                                </p>
                                <p
                                  className={
                                    darkMode ? "text-gray-300" : "text-gray-700"
                                  }
                                >
                                  {contact.value}
                                </p>
                              </div>
                            </div>
                          </a>
                        </motion.div>
                      </AnimatedSection>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>
      </Card3D>

      {/* Quote Section */}
      <section
        className={`py-16 relative z-10 ${
          darkMode
            ? "bg-gradient-to-r from-gray-800 to-blue-900"
            : "bg-gradient-to-r from-blue-100 to-blue-200"
        }`}
      >
        <div className="max-w-4xl mx-auto px-6 text-center">
          <motion.blockquote
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className={`text-2xl md:text-3xl font-medium italic leading-relaxed ${
              darkMode ? "text-blue-300" : "text-blue-900"
            }`}
          >
            &quot;Numbers are tools for us to send a rocket to the moon or weave
            the stories of our dreams into reality.&quot;
          </motion.blockquote>
        </div>
      </section>

      {/* Footer */}
      <footer
        className={`py-8 relative z-10 ${
          darkMode ? "bg-gray-900 text-gray-300" : "bg-blue-900 text-white"
        }`}
      >
        <div className="max-w-6xl mx-auto px-6 text-center">
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            © 2024 Yaman Alkın. Crafted with passion for data and business
            excellence.
          </motion.p>
        </div>
      </footer>
    </div>
  );
}

export default Home;
