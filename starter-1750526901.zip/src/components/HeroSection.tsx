import React from "react";
import { motion } from "framer-motion";
import { ArrowDownIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

interface HeroSectionProps {
  name?: string;
  subtitle?: string;
  introduction?: string;
  imageUrl?: string;
  onScrollDown?: () => void;
}

const HeroSection = ({
  name = "Yaman Alkın",
  subtitle = "Business & Economics Student • Data Enthusiast",
  introduction = "Welcome to my personal website — where business meets data and curiosity drives growth.",
  imageUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80",
  onScrollDown = () => {
    const aboutSection = document.getElementById("about");
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: "smooth" });
    }
  },
}: HeroSectionProps) => {
  return (
    <section
      id="home"
      className="min-h-screen flex flex-col justify-center items-center px-4 md:px-8 lg:px-16 bg-white"
    >
      <div className="max-w-6xl w-full flex flex-col lg:flex-row items-center justify-between gap-12">
        <motion.div
          className="flex-1 text-center lg:text-left"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-800 mb-4">
            {name}
          </h1>
          <h2 className="text-xl md:text-2xl text-blue-500 mb-6">{subtitle}</h2>
          <p className="text-lg md:text-xl text-gray-600 mb-8 max-w-2xl mx-auto lg:mx-0">
            {introduction}
          </p>
          <Button
            onClick={onScrollDown}
            className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-md flex items-center gap-2"
          >
            Learn More <ArrowDownIcon size={16} />
          </Button>
        </motion.div>

        <motion.div
          className="flex-1 flex justify-center lg:justify-end"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden border-4 border-blue-100 shadow-xl">
            <img
              src={imageUrl}
              alt="Yaman Alkın"
              className="w-full h-full object-cover"
            />
          </div>
        </motion.div>
      </div>

      <motion.div
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{
          duration: 1,
          delay: 1,
          repeat: Infinity,
          repeatType: "reverse",
        }}
      >
        <Button
          variant="ghost"
          size="icon"
          onClick={onScrollDown}
          className="rounded-full bg-blue-50 hover:bg-blue-100"
        >
          <ArrowDownIcon className="h-6 w-6 text-blue-500" />
        </Button>
      </motion.div>
    </section>
  );
};

export default HeroSection;
