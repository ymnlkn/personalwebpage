import React from "react";

const Dummycomponent = () => {
  return <div />;
};

export default Dummycomponent;
